/*
"name": "node-web-systematic-review",
"version": "1.0.0",
"author": "Luis Augusto Melo Rohten",
"date": 05/02/2016,
*/

//Call springer function!
if (global.gc) {
    global.gc();
} else {
    console.log('Garbage collection unavailable.  Pass --expose-gc '
      + 'when launching node to enable forced garbage collection.');
}

var springer = require('./springer/search-springer');
springer().execute();
